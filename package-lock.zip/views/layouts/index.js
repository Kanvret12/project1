module.exports = [
    { url: '/', text: 'Dashboard', active: 'index'},
    { url: '/about', text: 'About', active: 'about' },
    { url: 'https://wa.me/+6281387740552', text: 'Contact', active: 'contact'},
    { url: '/maps', text: 'Maps', active: 'maps' },
];